package util;

import java.sql.*;

public class Db {
   static final   String url = "jdbc:mysql://127.0.0.1:3306/test" ;
   static final  String user = "root";
   static  final String pass = "root";

   public static Connection main() {
      Connection conn = null;
      Statement stmt = null;
      try{
        Class.forName("com.mysql.cj.jdbc.Driver");
        conn = DriverManager.getConnection(url,user,pass);
        stmt = conn.createStatement();
        String sql = "select id from username,sex from person";
        ResultSet rs = stmt.executeQuery(sql);
          System.out.println("hello");
      }catch (SQLException | ClassNotFoundException se){
         se.printStackTrace();
      }
      return conn;
   }


}
//System.out.print("hello");