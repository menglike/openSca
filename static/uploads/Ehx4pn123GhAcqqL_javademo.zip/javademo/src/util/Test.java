package util;

import util.Db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class Test {

    public  static void  demo() throws SQLException {
//       Connection conn;
//       PreparedStatement stmt;
//        ResultSet rs;
//
//       String sql = "select * from person";
//       conn = Db.main();
//       stmt =  conn.prepareStatement(sql);
//       rs = stmt.executeQuery();
//       while(rs.next()){
////           System.out.println(rs.first());
//           System.out.println(rs.getInt("id"));
//       }
//       rs.close();
        System.out.println("hello");
    }
}
